<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;

class LogsaldoSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
    }
}
