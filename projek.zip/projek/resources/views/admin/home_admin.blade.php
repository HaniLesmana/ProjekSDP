@extends('admin.base-layout')
@section('main')
<div class="container">
    <h1>Hello, Admin</h1>
    <hr style="border: 1px solid gray;">
    <h2>Saldo : {{$admin}}</h2>
</div>
@endsection
