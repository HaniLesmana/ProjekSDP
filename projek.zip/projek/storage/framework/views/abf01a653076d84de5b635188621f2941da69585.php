<?php $__env->startComponent('mail::message'); ?>
<b>Hai <?php echo e($dtrans->htranssewa->user->user_nama); ?></b> <br>

Transaksi anda dengan <?php echo e($dtrans->pegawai->pegawai_nama); ?> sudah selesai. <br>
Terima kasih sudah menggunakan Babowe. <br>

<br>

Jangan lupa bagikan pengalamanmu menggunakan jasa <?php echo e($dtrans->pegawai->pegawai_nama); ?> dengan memberikan review dan rating <br>

<br>

HtransSewaID : <?php echo e($dtrans->htranssewa->id); ?> <br>
Tanggal Sewa : <?php echo e($dtrans->htranssewa->created_at); ?> <br>
Detail : <br>
<?php echo e($dtrans->pegawai->pegawai_jasa); ?>

<?php echo e($dtrans->pegawai->pegawai_nama); ?>

<?php echo e($dtrans->pegawai->pegawai_telepon); ?>




Thanks,<br>
<?php echo e(config('app.name')); ?>

<?php if (isset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d)): ?>
<?php $component = $__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d; ?>
<?php unset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>




<?php /**PATH C:\Users\Gigi\Documents\Gigi\Semester 5\ProjekSDP\projek\resources\views/emails/user_selesai.blade.php ENDPATH**/ ?>