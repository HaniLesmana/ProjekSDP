
<?php $__env->startSection('header'); ?>
    <?php echo $__env->make('admin.navbarAdmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('main'); ?>
<div class="container">
    <div class="row">
        <div class="col-sm-11"><h2>List Request Withdraw</h2></div>
    </div>
  <div class="table-responsive">
  <table class="table table-striped">
    <thead style="background-color:#E8D0B3;">
      <tr>
        <th>No</th>
        <th>Nama</th>
        <th>Saldo</th>
        <th>Jumlah Withdraw</th>
        <th>Tanggal</th>
        <th>Action</th>
      </tr>
    </thead>
    <tbody>
        <?php $ctr=1; ?>
        <?php $__currentLoopData = $wd; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <form action="/admin/acc_wd/<?php echo e($i->htranstpwd_id); ?>" method="get">
                <tr>
                    <td><?php echo e($ctr); ?></td>
                    <td>
                        <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $o=>$y): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($y->id == $i->user_id): ?>
                            <?php echo e($y->user_email); ?> || ID:<?php echo e($y->id); ?>

                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </td>
                    <th>
                        <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $y): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($y->id == $i->user_id): ?>
                            Rp.<?php echo e($y->user_saldo); ?>,-
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </th>
                    <td>Rp.<?php echo e($i->htranstpwd_total); ?>,-</td>
                    <td><?php echo e($i->htranstpwd_tanggal); ?></td>
                    <td>
                        <?php if($i->htranstpwd_status == 1): ?>
                            Success
                        <?php else: ?>
                            <button type="submit" style="border-radius:3px;border:1px solid black; background-color:#FACE7F;">
                                Accept
                            </button>
                        <?php endif; ?>
                    </td>
                </tr>
            </form>
            <?php $ctr++; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.base-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\GitHub_Repost\ProjekSDP\projek\resources\views/admin/listWithdraw.blade.php ENDPATH**/ ?>