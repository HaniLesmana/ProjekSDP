<?php $__env->startSection('header'); ?>
    <?php echo $__env->make('admin.navbarAdmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('main'); ?>
<style>
    .main{
        background-color:#DBD0C0;
        margin-top: -30px;
        padding: 55px;
    }
</style>
<div class="container mt-5 mb-5 d-flex justify-content-center" style="padding-top:20px; padding-bottom:20px;background-color:#DBD0C0">
    <div class="card px-1 py-4">
        <div class="card-body" style="width:400px;padding-top:30px; padding-bottom:30px;">
        <form action="<?php echo e(url('admin/prosesEditBarang/'.$id)); ?>" method="post">
            <?php echo csrf_field(); ?>
            
            <h5 class="card-title mb-3" style="text-align: center;">Edit Barang</h5>
            <?php $__currentLoopData = $barang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <?php if($b->barang_photo == "" || $b->barang_photo == null): ?>
                    <img src="<?php echo e(asset('/img/sapu.png')); ?>" alt="new-arrivals images"  height="350px" width="100%" style="object-fit:fill;margin-bottom:10px;border-radius:5px;">
                <?php else: ?>
                    <img src="<?php echo e(asset('/storage/photos/'.$b->barang_photo)); ?>" alt="new-arrivals images"  height="350px" width="100%" style="object-fit:fill;margin-bottom:10px;border-radius:5px;">
                <?php endif; ?>
                <div class="row">
                    <div class="col-sm-12">
                        <div class="form-group">
                            <input class="form-control" type="text" name="id" placeholder="ID Barang" value="<?php echo e(old('id') ? old('id') : $b->id); ?>" readonly> </div>
                            <?php $__errorArgs = ['id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span style='color: red'><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
                <div class="row">
                    <div class="col-sm-12">
                        <div class="form-group">
                            <div class="input-group"> <input class="form-control" name="nama" type="text" placeholder="Nama Barang" value="<?php echo e(old('nama') ? old('nama') : $b->barang_nama); ?>"> </div>
                            <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span style='color: red'><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-sm-12">
                        <div class="form-group">
                            <div class="input-group"> <input class="form-control" type="number" name="harga" placeholder="Harga" value="<?php echo e(old('harga') ? old('harga') : $b->barang_harga); ?>"> </div>
                            <?php $__errorArgs = ['harga'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span style='color: red'><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-sm-12">
                        <div class="form-group">
                            <div class="input-group"> <input class="form-control" type="number" name="stok" placeholder="Stok" value="<?php echo e(old('stok') ? old('stok') : $b->barang_stok); ?>" readonly> </div>
                            <?php $__errorArgs = ['stok'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span style='color: red'><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                </div>
                
                

                <a href="" data-target="#pilihalamat" data-toggle="modal"><button class="btn btn-warning btnTrans" data-target="#exampleModal" data-toggle="modal">Edit Stock</button></a>

                <!-- <div class="row">
                    <div class="col-sm-12">
                        <div class="form-group">

                            <div class="input-group"> <input class="form-control" type="text" name="statusBarang" placeholder="Status" value="<?php echo e(old('statusBarang') ? old('statusBarang') : $b->barang_status); ?>"> </div>
                            <?php $__errorArgs = ['statusBarang'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span style='color: red'><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                </div> -->
                <br> <br>
                <div class="row">
                    <div class="col-sm-12">
                        <div class="form-group">
                            
                                <select name="kategori" id="">
                                <?php $__currentLoopData = $kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($kat->id == $b->barang_kategori): ?>
                                        <option value="<?php echo e($kat->id); ?>" selected><?php echo e($kat->kategori_nama); ?></option>
                                    <?php else: ?>
                                        <option value="<?php echo e($kat->id); ?>"><?php echo e($kat->kategori_nama); ?><option>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php $__errorArgs = ['kategori'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span style='color: red'><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <button style="color:white; width: 375px;border-radius:3px;border:1px solid black; background-color:#FACE7F;text-align:center;">
            <a href="#" style="text-decoration: none;color:white">Edit</a>
            </button>
            </form>
        </div>
    </div>
</div>

<!-- MODAL ADD STOCK -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Edit Stock</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
            </div>

            <form method="get" action="<?php echo e(url('/admin/prosesEditStock/'.$b->id)); ?>">
                <div class="modal-body" style="" >
                    <div style="float:left;width:60px;">
                        <label style="font-weight:normal;height:27px;">Jumlah</label> <br>
                        <label style="font-weight:normal;height:27px;">Jenis</label>

                    </div>
                    <div style="float:left">
                        : <input type="number" name="stok" id="" min="1" style="margin-bottom:7px;"><br>
                        : <input type="radio" name="txtstok" id="tambah" value="Tambah"> Tambah
                        <input type="radio" name="txtstok" id="kurang" value="Kurang" style="margin-left:5px;"> Kurang<br>
                    </div>

                </div>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-warning">Confirm</button>
                    <button type="submit" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.base-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Gigi\Documents\Gigi\Semester 5\ProjekSDP\projek\resources\views/admin/editBarang_Admin.blade.php ENDPATH**/ ?>