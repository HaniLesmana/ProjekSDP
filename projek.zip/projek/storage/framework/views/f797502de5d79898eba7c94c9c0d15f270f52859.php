<nav class="navbar navbar-expand-lg navbar navbar-light fixed-top"  style="background-color: rgba(255,255,255,0.9);  background-image: linear-gradient( rgba(0,0,0,0.1),rgba(220,220,220,0),rgba(225,225,225,0));" >
    <div class="container">
      <a class="navbar-brand" id="gambar" href="#"></a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
        <div class="navbar-nav ml-auto">
            <a class="nav-item nav-link active" href="/home/admin">Home</a>
          <a class="nav-item nav-link active" href="/admin/listpegawai">List Pegawai</a>
          <a class="nav-item nav-link " href="/admin/listbarang" >List Barang</a>
          <a class="nav-item nav-link" href="#">List Voucher</a>
          <button type ="button" class="btn btn-primary tombol" style="align:right;"><a href="index" style="text-decoration:none;color:white;">Sign Out</a></button>
        </div>
      </div>
    </div>
  </nav>
<?php /**PATH D:\Kuliah\Semester_5\5_SDP\ProjekSDP\projek\resources\views/admin/navbarAdmin.blade.php ENDPATH**/ ?>