<!DOCTYPE html>
<html lang="en">
<head>
  <title>Babowe's Employee Rating Review Report</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<style>
    #gambar{
        background-image: url(img/title.png);
        background-size: contain;
        background-repeat: no-repeat;
        background-position: center;
        height: 60px;
        width: 250px;
        margin-top:6px;
        position:inherit;
        float: right;
    }
    table {
    font-family: arial, sans-serif;
    border-collapse: collapse;
    width: 100%;
    }

    td, th {
    border: 1px solid black;
    text-align: left;
    padding: 8px;
    }

    tr:nth-child(even) {
    background-color: #dddddd;
    }
</style>
<body>
    <?php
    $path = 'img/title.png';
    $type = pathinfo($path, PATHINFO_EXTENSION);
    $data = file_get_contents($path);
    $base64 = 'data:image/' . $type . ';base64,' . base64_encode($data);
?>
<div class="container">
    <img src="<?php echo $base64?>" width="250" height="60"/><br>
    <div style="clear: both"></div>
    <h1>Laporan Rating Review User </h1>
  
  <table class="table table-hover">
    <thead>
      <tr>
        <th>Pegawai Id</th>
        <th>Nama</th>
        <th>Rating</th>
        <th>Detail</th>
      </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $pegawai; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
                $rata2 = 0;
                $temp = 0;
            ?>
            <?php $__currentLoopData = $p->reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $temp += $r->rating;
                ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php
                if(count($p->reviews) > 0){
                    $rata2 = $temp / count($p->reviews);
                }
            ?>
            <tr>
                <td><?php echo e($p->id); ?></td>
                <td><?php echo e($p->pegawai_nama); ?></td>
                <td><?= round($rata2,2)?></td>
                <td>
                    <table style="border:1px solid black;">
                        <tr style="border:1px solid black">
                            <th>User Id</th>
                            <th>User </th>
                            <th>Rating</th>
                            <th>Review</th>
                        </tr>
                        <?php $__currentLoopData = $rating; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $y => $x): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($x->pegawai_id == $p->id): ?>
                                <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $z => $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($u->id == $x->user_id): ?>
                                        <td><?php echo e($u->id); ?></td>
                                        <td><?php echo e($u->user_nama); ?></td>
                                        <td><?php echo e($x->rating); ?></td>
                                        <td><?php echo e($x->review); ?></td>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>
</div>

</body>
</html>
<?php /**PATH D:\GitHub_Repost\ProjekSDP\projek\resources\views/admin/report/ratingReviewPdf.blade.php ENDPATH**/ ?>