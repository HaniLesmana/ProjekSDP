<?php echo e($slot); ?>

<?php /**PATH C:\Users\Gigi\Documents\Gigi\Semester 5\ProjekSDP\projek\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>