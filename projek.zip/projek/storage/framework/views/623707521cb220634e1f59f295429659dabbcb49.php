<!DOCTYPE html>
<html lang="en">
<head>
  <title>Babowe Report's</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<style>
    #gambar{
        background-image: url(img/title.png);
        background-size: contain;
        background-repeat: no-repeat;
        background-position: center;
        height: 60px;
        width: 250px;
        margin-top:6px;
        position:inherit;
        float: right;
    }
    table {
    font-family: arial, sans-serif;
    border-collapse: collapse;
    width: 100%;
    }

    td, th {
    border: 1px solid #dddddd;
    text-align: left;
    padding: 8px;
    }

    tr:nth-child(even) {
    background-color: #dddddd;
    }
</style>
<body>
<?php
    $path = 'img/title.png';
    $type = pathinfo($path, PATHINFO_EXTENSION);
    $data = file_get_contents($path);
    $base64 = 'data:image/' . $type . ';base64,' . base64_encode($data);
?>
<div class="container">
    <img src="<?php echo $base64?>" width="250" height="60"/><br>
    <div style="clear: both"></div>
    <h1>Laporan Transasi Barang</h1>
  
  <table class="table table-hover">
    <thead>
      <tr>
        <th>ID</th>
        <th>User ID</th>
        <th>Pegawai ID </th>
        <th>Total</th>
        <th>Detail</th>
      </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $htranssewa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr style="border-bottom: 2px solid black">
                <td><?php echo e($p->id); ?></td>
                <td><?php echo e($p->user_id); ?></td>
                <td><?php echo e($p->pegawai_id); ?></td>
                <td>Rp.<?php echo e($p->hBarang_total); ?>,-</td>
                <td>
                    <table style="width:500px;border:1px solid black;">
                        <tr style="border:1px solid black">
                            <th> Dtrans ID</th>
                            <th> Pegawai ID </th>
                            <th>Tanggal sewa</th>
                            <th>Harga sewa</th>
                            <th>Alamat</th>
                            <th>Status</th>
                        </tr>
                        <?php $__currentLoopData = $dtranssewa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $y => $x): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($x->hSewa_id == $p->id): ?>
                                <div style="background-color: #F5EEDC; padding:5px 5px 5px 5px; border-radius:5px; margin-bottom:7px;">
                                    <div>Dtrans ID :<?php echo e($x->id); ?></div>
                                    <?php $__currentLoopData = $barang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t => $q): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($q->id == $x->barang_id): ?>
                                        <div>Barang :<?php echo e($x->barang_id); ?>, <?php echo e($q->barang_nama); ?></div>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <div>Jumlah :<?php echo e($x->barang_jumlah); ?></div>
                                </div>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </table>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>
</div>

</body>
</html>
<?php /**PATH D:\GitHub_Repost\ProjekSDP\projek\resources\views/admin/report/trans_barang_pdf.blade.php ENDPATH**/ ?>