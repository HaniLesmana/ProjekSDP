<?php if(isset($dtransewa)): ?>
    <?php $__currentLoopData = $dtransewa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i =>$dt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e($i+1); ?></td>
        <?php if($dt->pegawai_photo==null): ?>
            <td><a href="#"><img src="<?php echo e(asset('img/person.png')); ?>" class="avatar" alt="Avatar" style="height:50px;"> <?php echo e($dt->pegawai->pegawai_nama); ?></a></td>
        <?php else: ?>
            <td><a href="#"><img src="<?php echo e(asset('storage/'.'P'.$dt->pegawai_id)); ?>" class="avatar" alt="Avatar"> <?php echo e($dt->pegawai->pegawai_nama); ?></a></td>
        <?php endif; ?>

        <td><?php echo e($dt->dSewa_alamat); ?></td>
        <td><?php echo e($dt->dSewa_tanggal); ?></td>
        <?php if($dt->dSewa_status_accpegawai==0): ?>
            <td><span class="status text-danger">&bull;</span>Cancel</td>
        <?php elseif($dt->dSewa_status_accpegawai==1): ?>
            <td><span class="status text-info">&bull;</span>Accept</td>
        <?php elseif($dt->dSewa_status_accpegawai==2): ?>
            <td><span class="status text-warning">&bull;</span>Pending</td>
        <?php elseif($dt->dSewa_status_accpegawai==3): ?>
            <td><span class="status text-success">&bull;</span>Finish</td>
        <?php endif; ?>

        <td>Rp. <?php echo e($dt->dSewa_harga); ?></td>
        <td><a href="#" class="view" title="View Details" data-toggle="tooltip"><i class="material-icons">&#xE5C8;</i></a></td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
<?php /**PATH C:\Users\Gigi\Documents\Gigi\Semester 5\ProjekSDP\projek\resources\views/user/history_filter_pegawai.blade.php ENDPATH**/ ?>