<!DOCTYPE html>
<html lang="en">
<head>
  <title>Babowe Top Up Withdraw Report's</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<style>
    #gambar{
        background-image: url(img/title.png);
        background-size: contain;
        background-repeat: no-repeat;
        background-position: center;
        height: 60px;
        width: 250px;
        margin-top:6px;
        position:inherit;
        float: right;
    }
    table {
    font-family: arial, sans-serif;
    border-collapse: collapse;
    width: 100%;
    }

    td, th {
    border: 1px solid black;
    text-align: left;
    padding: 8px;
    }

    tr:nth-child(even) {
    background-color: #dddddd;
    }
</style>
<body>
    <?php
    $path = 'img/title.png';
    $type = pathinfo($path, PATHINFO_EXTENSION);
    $data = file_get_contents($path);
    $base64 = 'data:image/' . $type . ';base64,' . base64_encode($data);
?>
<div class="container">
    <img src="<?php echo $base64?>" width="250" height="60"/><br>
    <div style="clear: both"></div>
    <h1>Laporan TopUp Withdraw</h1>
  
  <table class="table table-hover">
    <thead>
      <tr>
        <th>Id Transaksi</th>
        <th>User ID</th>
        <th>Tanggal</th>
        <th>Total</th>
        <th>Tipe</th>
        <th>Status</th>
        <th>Token</th>
        <th>Payment Status</th>
        <th>Detail</th>

      </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $htranstpwd; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr style="border-bottom: 1px solid black">
                <td><?php echo e($p->htranstpwd_id); ?></td>
                <td><?php echo e($p->user_id); ?></td>
                <td><?php echo e($p->htranstpwd_tanggal); ?></td>
                <td><?php echo e($p->htranstpwd_total); ?></td>
                <td><?php echo e($p->htranstpwd_tipe); ?></td>
                <td><?php echo e($p->htranstpwd_status); ?></td>
                <td><?php echo e($p->token_payment); ?></td>
                <td><?php echo e($p->status_payment); ?></td>
                <td>
                    <table style="border:1px solid black;">
                        <tr style="border:1px solid black">
                            <th> Dtrans ID</th>
                            <th> Nominal </th>
                            <th> Jumlah </th>
                        </tr>
                        <?php $__currentLoopData = $dtranstpwd; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $y => $x): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($x->htranstpwd_id == $p->htranstpwd_id): ?>
                                <tr>
                                    <td><?php echo e($x->id); ?></td>
                                    <td><?php echo e($x->htranstpwd_nominal); ?></td>
                                    <td><?php echo e($x->htranstpwd_jumlah); ?></td>
                                </tr>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </table>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>
</div>

</body>
</html>
<?php /**PATH D:\GitHub_Repost\ProjekSDP\projek\resources\views/admin/report/topupPDF.blade.php ENDPATH**/ ?>