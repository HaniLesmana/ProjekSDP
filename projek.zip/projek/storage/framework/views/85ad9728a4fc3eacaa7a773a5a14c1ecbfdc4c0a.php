<?php $__env->startSection('header'); ?>
    <?php echo $__env->make('admin.navbarAdmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('main'); ?>
Report
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.base-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Kuliah\Semester_5\5_SDP\ProjekSDP\projek\resources\views/admin/home_admin.blade.php ENDPATH**/ ?>