
<?php $__env->startSection('header'); ?>
    <?php echo $__env->make('admin.navbarAdmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('main'); ?>
<div class="container">
    <div class="row">
        <div class="col-sm-11"><h2>List Request Top Up</h2></div>
    </div>
  <div class="table-responsive">
  <table class="table table-striped">
    <thead style="background-color:#E8D0B3;">
      <tr>
        <th>ID</th>
        <th>Nama</th>
        <th>Jumlah Top Up</th>
        <th>Jenis</th>
        <th>Tanggal</th>
        <th>Status</th>
        <th></th>
      </tr>
    </thead>
    <?php if(isset($datas)): ?>
        <?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tbody>
                <td><?php echo e($data->htranstpwd_id); ?></td>
                <td><?php echo e($data->user->user_nama); ?></td>
                <td><?php echo e($data->htranstpwd_total); ?></td>
                <td><?php echo e($data->htranstpwd_tipe); ?></td>
                <td><?php echo e(date('d-m-Y h:m:s', strtotime($data->htranstpwd_tanggal))); ?></td>
                <?php if($data->htranstpwd_status == "0"): ?>
                    <td>Declined</td>
                <?php elseif($data->htranstpwd_status == "1"): ?>
                    <td>Accepted</td>
                <?php else: ?>
                    <td>Pending</td>
                <?php endif; ?>
                <td>
                    <button type="submit" style="border-radius:3px;border:1px solid black; background-color:#FACE7F;">
                        <a href="<?php echo e(url('admin/detailTopUp/'.$data->htranstpwd_id.'/'.$data->user->user_email )); ?>" style="text-decoration:none; color:white;">
                            Detail
                        </a>
                    </button>
                </td>
            </tbody>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
    
  </table>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.base-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\GitHub_Repost\ProjekSDP\projek\resources\views/admin/listRequest.blade.php ENDPATH**/ ?>