<?php $__env->startSection('main'); ?>
<div class="container">
    <div class="row">
        <div class="col-sm-11"><h2>Laporan Rating Review Pegawai</h2></div>
        <div class="col-md-12" style="margin:10px 0 10px 0;">
            <form action="reportRatingReviewPDF" method="GET">
                <button type="submit" class="btn btn-primary"> Print PDF <i class="fas fa-file-pdf"></i></button>
            </form>
        </div>
    </div>

  <div class="table-responsive" id="contentss">
  <table class="table table-striped" id="myTable">
    <thead style="background-color:#E8D0B3;">
      <tr>
        <th>Pegawai Id</th>
        <th>Nama</th>
        <th>Rating</th>
        <th>Foto</th>
        <th></th>
      </tr>
    </thead>
    <tbody>
    <?php $__currentLoopData = $pegawai; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php
            $rata2 = 0;
            $temp = 0;
        ?>
        <?php $__currentLoopData = $p->reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
                $temp += $r->rating;
            ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php
            if(count($p->reviews) > 0){
                $rata2 = $temp / count($p->reviews);
            }
        ?>
              <tr>
                    <td><?php echo e($p->id); ?></td>
                    <td><?php echo e($p->pegawai_nama); ?></td>
                    <td><?= round($rata2,2)?></td>
                    <td><?php echo e($p->pegawai_photo); ?></td>
                    <td>
                        <button type="button" class="btn btn-warning" data-toggle="modal" data-target="#exampleModal<?php echo e($p->id); ?>" style="text-decoration: none; border:none; text-align:center;">
                            Detail
                        </button>
                    </td>
                </tr>

            <div class="modal fade" id="exampleModal<?php echo e($p->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h3 class="modal-title" id="exampleModalLabel">Review</h3>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                        </div>
                        <div class="modal-body">
                            <?php $__currentLoopData = $rating; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $y => $x): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($x->pegawai_id == $p->id): ?>
                                <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $z => $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($u->id == $x->user_id): ?>
                                        <div style="background-color: #F5EEDC; padding:5px 5px 5px 5px; border-radius:5px; margin-bottom:7px;">
                                            <div>User Id : <?php echo e($u->id); ?></div>
                                            <div>User : <?php echo e($u->user_nama); ?></div>
                                            <div>Rating : <?php echo e($x->rating); ?></div>
                                            <div>Review : <?php echo e($x->review); ?></div>
                                        </div>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <div class="modal-footer">
                        </div>
                    </div>
                </div>
            </div>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.base-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\GitHub_Repost\ProjekSDP\projek\resources\views/admin/report/reportRating.blade.php ENDPATH**/ ?>