<?php $__env->startSection('header'); ?>
    <?php echo $__env->make('admin.navbarAdmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('main'); ?>
<div class="container">
    <div class="row">
        <div class="col-sm-11"><h2>List Pegawai</h2></div>
            <div class="col-sm-11">
                <button type="submit" style="width:250px;align:right;border-radius:3px;border:1px solid black; background-color:#FACE7F;align:right; width:65px; font-size:9.5px;">
                    <a href="/admin/addPegawai" style="text-decoration: :none; color:white;">
                        Add Pegawai
                    </a>
                </button>
            </div>

    </div>
  <div class="table-responsive">
  <table class="table table-striped">
    <thead style="background-color:#E8D0B3;">
      <tr>
        <th>No</th>
        <th>NIK</th>
        <th>Id</th>
        <th>Email</th>
        <th>Nama</th>
        <th>Alamat</th>
        <th>Password</th>
        <th>Telepon</th>
        <th>Jasa</th>
        <th>Saldo</th>
        <th>Status</th>
        <th>Edit</th>
        <th>Delete</th>
      </tr>
    </thead>
    <tbody>
    <?php $__currentLoopData = $pegawai; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($i+1); ?></td>
            <td><?php echo e($p->pegawai_nik); ?></td>
            <td><?php echo e($p->pegawai_id); ?></td>
            <td><?php echo e($p->pegawai_email); ?></td>
            <td><?php echo e($p->pegawai_nama); ?></td>
            <td><?php echo e($p->pegawai_alamat); ?></td>
            <td><?php echo e($p->pegawai_password); ?></td>
            <td><?php echo e($p->pegawai_telepon); ?></td>
            <td><?php echo e($p->pegawai_jasa); ?></td>
            <td><?php echo e($p->pegawai_saldo); ?></td>
            <td><?php echo e($p->pegawai_status); ?></td>
            <td>
                <button type="submit" style="border-radius:3px;border:1px solid black; background-color:#FACE7F;">
                    <a href="/admin/editPegawai/<?php echo e($p->pegawai_id); ?>" style="text-decoration: :none; color:white;">
                        Edit
                    </a>
                </button>
            </td>
            <td>
                <button type="submit" style="text-decoration: none; border:none; background-color:white; text-align:center;">
                    
                    <a href="/admin/prosesDeletePegawai/<?php echo e($p->pegawai_id); ?>" class="fa fa-trash" style="font-size:18px;color:red;">

                    </a>
                </button>
            </td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        

    </tbody>
  </table>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.base-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Kuliah\Semester_5\5_SDP\ProjekSDP\projek\resources\views/admin/listPegawai_Admin.blade.php ENDPATH**/ ?>