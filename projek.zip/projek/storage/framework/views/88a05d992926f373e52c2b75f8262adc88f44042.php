    <!-- Navbar -->
    <?php $__env->startSection('header'); ?>
        <?php echo $__env->make('user.navbarUser', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php $__env->stopSection(); ?>
    <!-- Akhir Navbar -->
    <?php $__env->startSection('main'); ?>
    <div class="container">
        <form  method="post" action="<?php echo e(url('home/do_pembayaran')); ?>">
            <?php echo csrf_field(); ?>
        <div class="shadow-lg p-3 mb-5 bg-white rounded">

            <h2>Metode Bayar</h2>
            <?php dd($user_voucher); ?>
            <hr style="margin-top:20px;">

            <div id="contItems">
                <div style="float:left;" class="mr-4">
                    <label class="lab" style="line-height:20px;">Total</label><br>
                    <label class="lab" style="line-height:20px;">Voucher</label><br>
                    <label class="lab" style="line-height:20px;">Potongan</label>
                </div>
                <div style="float:left;">
                    <input type="hidden" id="tot" value="<?php echo e($total); ?>">
                    <label class="lab" style="line-height:20px;"><?php echo e($total); ?></label><br>
                    <select class="form-control-sm" name="datavoucher" id="dt" style="float:left;">
                        
                            <option value="-1">-</option>
                            <?php $__currentLoopData = $user_voucher; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $uv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                
                                    <option value="<?php echo e($uv->voucher->id); ?>"><?php echo e($uv->voucher->voucher_nama); ?></option>
                                
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                    </select><br>
                    <?php $__currentLoopData = $user_voucher; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $uv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <input type="hidden" id="P<?php echo e($uv->id); ?>" value="<?php echo e($uv->voucher->voucher_potongan); ?>">
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <label class="lab" style="line-height:20px;" id="txtpotongan">0</label>
                </div>
            </div>
            <div style="clear: both;"></div>
            <hr>
            <div>
                <div style="float:right;">
                    <label style="color:grey;font-weight:semibold;font-size:20px;" id="total">Total :  <?php echo e($total); ?></label>
                    
                    <input type="hidden" name="totalhidden" id="totalhidden" value="<?php echo e($total); ?>">
                    
                    <button type="submit" class="btn btn-warning" style="color:white;margin-left:10px;margin-top:-5px;" onclick="btncheckout()">Checkout</button>
                </div>
                <div style="clear:both"></div>
            </div>
        </form>
    </div>
    <script>
        $(document).ready(function() {
            $('[name=datavoucher]').on('change', function() {
                if(this.value==-1){
                    var temp=$('#tot').val();
                    $('#txtpotongan').html(0);
                    $('#total').html("Total : "+temp);
                    $('#totalhidden').val(temp);
                }
                else{
                    $('#txtpotongan').html($("#"+"P"+this.value).val());
                    var temp=$('#tot').val()-parseInt($('#txtpotongan').html());
                    $('#total').html("Total : "+temp);
                    $('#totalhidden').val(temp);
                }
            });
        });

    </script>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('user.base-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\GitHub_Repost\ProjekSDP\projek\resources\views/user/pembayaran.blade.php ENDPATH**/ ?>