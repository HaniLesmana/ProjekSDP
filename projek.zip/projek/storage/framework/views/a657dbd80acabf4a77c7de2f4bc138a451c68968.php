
<!-- Navbar -->
<?php $__env->startSection('header'); ?>
    <?php echo $__env->make('user.navbarUser', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<!-- Akhir Navbar -->
<?php $__env->startSection('main'); ?>


    <div class="container">
        <div class="section-header" style="text-align:left;">
            <h2>On going</h2>
        </div>


            <?php echo csrf_field(); ?>
            <?php $__currentLoopData = $dtransewa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key =>$d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="shadow-lg" style="display: flex;border-radius:5px;">
                <div class="card" style="float:left;">
                    <?php if($d->pegawai->pegawai_photo=="" || $d->pegawai->pegawai_photo==null): ?>
                        <img src="<?php echo e(asset('/img/profile.png')); ?>" class="card-img-top" style="height:9rem;width:10rem;">
                    <?php else: ?>
                        <img src="<?php echo e(asset('/storage/photos/'.$d->pegawai->pegawai_photo)); ?>" class="card-img-top" style="height:9rem;width:10rem;">
                    <?php endif; ?>

                </div>
                <div class="card-body" style="width:15rem;float:left;">
                    <h5 class="card-title"><?php echo e($d->pegawai->pegawai_nama); ?></h5>
                    <p class="card-text"><?php echo e($d->pegawai->pegawai_telepon); ?></p>
                    <p class="card-text"><?php echo e($d->pegawai->pegawai_alamat); ?></p>
                </div>
                <div class="card-body" style="width:15rem;float:left;display:flex;">
                    <form action="<?php echo e(url('/user/detailongoing/'.$d->id)); ?>" method="get">
                        <button type="submit" class="btn btn-success mr-3" name="btndetail">Detail</button>
                    </form>
                    <form action="<?php echo e(url('/user/chat/'.$d->pegawai->id)); ?>" method="get">
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="btn btn-warning mr-3" name="btnchat">Chat</button>
                    </form>
                    <?php if($d->dSewa_status_accpegawai==2): ?>
                        <form action="" method="get">
                            <button type="submit" class="btn btn-secondary" name="btnstatus" disabled>Pending</button>
                        </form>
                    <?php elseif($d->dSewa_status_accpegawai==1): ?>
                        <form action="<?php echo e(url('/user/status_pesanan_finish/'.$d->id)); ?>" method="get">
                            <button type="submit" class="btn btn-success" name="btnstatus">Finish</button>
                        </form>
                    <?php endif; ?>
                </div>
            </div>
            <hr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.base-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\GitHub_Repost\ProjekSDP\projek\resources\views/user/ongoingtrans.blade.php ENDPATH**/ ?>