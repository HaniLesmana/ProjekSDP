<?php $__env->startSection('main'); ?>
<div class="container">
    <div class="row">
        <div class="col-sm-11"><h2>Laporan Pendapatan</h2></div>
        <div class="col-md-12" style="margin:10px 0 10px 0;">
            <form action="reportPendapatanPDF" method="GET">
                <button type="submit" class="btn btn-primary"> Print PDF <i class="fas fa-file-pdf"></i></button>
            </form>
        </div>
    </div>

  <div class="table-responsive" id="contentss">
  <table class="table table-striped" id="myTable">
    <thead style="background-color:#E8D0B3;">
      <tr>
        <th>Pegawai Id</th>
        <th>Nama</th>
        <th>Saldo</th>
        <th></th>
      </tr>
    </thead>
    <tbody>
    <?php $__currentLoopData = $pegawai; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($p->id); ?></td>
            <td><?php echo e($p->pegawai_nama); ?></td>
            <td><?php echo e($p->pegawai_saldo); ?></td>
            <td>
                <button type="submit" class="btn btn-warning" data-toggle="modal" data-target="#exampleModal<?php echo e($p->id); ?>" style="text-decoration: none; border:none; text-align:center;">
                    Detail
                </button>
            </td>
        </tr>
        <div class="modal fade" id="exampleModal<?php echo e($p->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h3 class="modal-title" id="exampleModalLabel">Detail Pendapatan</h3>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                    </div>
                    <div class="modal-body">
                        <?php $ctr=0; ?>
                        <?php $__currentLoopData = $dtranssewa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $y => $x): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($x->pegawai_id == $p->id): ?>
                            <?php $ctr++; ?>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <div style="background-color: #F5EEDC; padding:5px 5px 5px 5px; border-radius:5px; margin-bottom:7px;">
                            <div>Jumlah Transaksi: <?= $ctr ?></div>
                        </div>
                    </div>
                    <div class="modal-footer">
                    </div>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.base-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\GitHub_Repost\ProjekSDP\projek\resources\views/admin/report/reportPendapatan.blade.php ENDPATH**/ ?>