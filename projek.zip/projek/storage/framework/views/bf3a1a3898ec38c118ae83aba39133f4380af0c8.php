
<?php $__env->startSection('main'); ?>
<div class="container">
    <div class="row">
        <div class="col-sm-11"><h2>Laporan Transaksi Barang</h2></div>
        <div class="col-md-12" style="margin:10px 0 10px 0;">
            <form action="transaksi_barangPDF" method="GET">
                <button type="submit" class="btn btn-primary"> Print PDF <i class="fas fa-file-pdf"></i></button>
            </form>
        </div>
    </div>
    <form action="<?php echo e(url('/report/reportpembelianbarang_ajax/')); ?>" method="get">
    <div class="table-filter">
        <div class="row">
            <div class="col-sm-12">
                <div class="filter-group">
                    <label>From Date</label>
                    <input type="date" class="form-control" name="search1" id="search1">
                </div>
                <div class="filter-group">
                    <label>To Date</label>
                    <input type="date" class="form-control" name="search2" id="search2">
                </div>
            </div>
        </div>
    </div>
    <button type="submit" class="btn btn-warning">Search</button>
    </form>
  <div class="table-responsive" id="contentss">
  <table class="table table-striped" id="myTable">
    <thead style="background-color:#E8D0B3;">
      <tr>
        <th>ID</th>
        <th>User Nama</th>
        <th>Pegawai Nama </th>
        <th>Total</th>
        <th></th>
      </tr>
    </thead>
    <tbody id="listReport">
    <!-- <?php $__currentLoopData = $htranssewa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> -->
        <?php $__currentLoopData = $dtranssewa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($d->id); ?></td>
            <td><?php echo e($d->htranssewa->user->user_nama); ?></td>
            <td><?php echo e($d->pegawai->pegawai_nama); ?></td>
            <td>Rp.<?php echo e($d->htranssewa->hSewa_total); ?>,-</td>
            <td>
                <button type="button" class="btn btn-warning" data-toggle="modal" data-target="#exampleModal<?php echo e($d->id); ?>" style="text-decoration: none; border:none; text-align:center;">
                    Detail
                </button>
            </td>
        </tr>
        
        <div class="modal fade" id="exampleModal<?php echo e($d->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                    <h3 class="modal-title" id="exampleModalLabel">Detail Transaksi</h3>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                    </div>
                    <div class="modal-body">
                        <!-- <?php $__currentLoopData = $dtranssewa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $y => $x): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($x->id == $p->id): ?> -->
                                <div style="background-color: #F5EEDC; padding:5px 5px 5px 5px; border-radius:5px; margin-bottom:7px;">
                                    <div>Dtrans ID :<?php echo e($d->id); ?></div>
                                    <div>Barang: <?php echo e($d->dtransbarang->barang_id); ?>,<?php echo e($d->dtransbarang->barang->barang_nama); ?></div>
                                    <!-- <?php $__currentLoopData = $barang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t => $q): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($q->id == $x->barang_id): ?>
                                        <div>Barang :<?php echo e($x->barang_id); ?>, <?php echo e($q->barang_nama); ?></div>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> -->
                                    <div>Jumlah :<?php echo e($d->dtransbarang->barang_jumlah); ?></div>
                                </div>
                            <!-- <?php endif; ?> -->
                        <!-- <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> -->
                    </div>
                    <div class="modal-footer">
                    </div>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


    <!-- <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> -->
    </tbody>
  </table>
  </div>
</div>
<script>
// $(document).ready(function() {
//     $("#search1").change(function(){
//         if ($("#search1").val()==""||$("#search2").val()==""){
//             alert("tanggal masih ada yang kosong");
//         }
//         else{
//             filter();
//         }
//     });
//     $("#search2").on('change',function(){
//         //alert(this.value);
//         if ($("#search1").val()==""||$("#search2").val()==""){
//             alert("tanggal masih ada yang kosong");
//         }
//         else{
//             filter();
//         }
//     });
// });
// function filter(){
//     if ($("#search1").val()!=""&&$("#search2").val()!=""){
//         $.ajax({
//             type: 'get',
//             url: '/report/reportpembelianbarang_ajax/'+$("#search1").val()+"/"+$("#search2").val(),
//             success: function(data) {
//                 // alert('testif($("#listReport").){
//                 if($("#contentss").is(':empty')){
//                     $("#contentss").append(data);
//                 }
//                 else{
//                     $("#contentss").empty();
//                     $("#contentss").append(data);
//                 }

//             }
//         });
//     }
// }
// </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.base-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\GitHub_Repost\ProjekSDP\projek\resources\views/admin/report/pembelian_barang.blade.php ENDPATH**/ ?>