<nav class="navbar navbar-expand-lg navbar navbar-light fixed-top"  style="background-color: rgba(255,255,255,0.9);  background-image: linear-gradient( rgba(0,0,0,0.1),rgba(220,220,220,0),rgba(225,225,225,0));">
    <div class="container">
        <a class="navbar-brand" id="gambar" href="#"></a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
        <div class="navbar-nav ml-auto">
            
            <form action="<?php echo e(url('home/pegawai')); ?>" method="get">
                <a class="nav-item nav-link">
                    <input class="btn" type="submit" value="Home">
                </a>
                
            </form>
            
            <form action="<?php echo e(url('pegawai/pesanan')); ?>" method="get">
                <a class="nav-item nav-link">
                    <input class="btn" type="submit" value="Order">
                </a>
                
            </form>
            
            <form action="<?php echo e(url('pegawai/history')); ?>" method="get">
                <a class="nav-item nav-link">
                    <input class="btn" type="submit" value="History">
                </a>
                
            </form>
            <form action="<?php echo e(url('pegawai/profile')); ?>" method="get">
                <a class="nav-item nav-link">
                    <input class="btn" type="submit" value="Profile">
                </a>
                
            </form>
            <form action="<?php echo e(url('pegawai/chat')); ?>" method="get">
                <a class="nav-item nav-link">
                    <input class="btn" type="submit" value="Chat">
                </a>
                
            </form>
            <form action="<?php echo e(url('pegawai/withdraw')); ?>" method="get">
                <a class="nav-item nav-link">
                    <input class="btn" type="submit" value="Withdraw">
                </a>
            </form>
            <form action="<?php echo e(url('/logout')); ?>" method="get">
                <a class="nav-item nav-link">
                    <input class="btn btn-danger" type="submit" value="Sign Out">
                </a>
            </form>
          
        </div>
      </div>
    </div>
  </nav>
<?php /**PATH C:\Users\Gigi\Documents\Gigi\Semester 5\ProjekSDP\projek\resources\views/pegawai/navbarPegawai.blade.php ENDPATH**/ ?>