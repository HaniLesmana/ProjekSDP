
<!-- Navbar -->
<?php $__env->startSection('header'); ?>
    <?php echo $__env->make('user.navbarUser', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<!-- Akhir Navbar -->
<?php $__env->startSection('main'); ?>
    <!-- Google Font -->
    <link href="https://fonts.googleapis.com/css?family=Montserrat:400,500,700" rel="stylesheet">

    <!-- Bootstrap -->
    <link type="text/css" rel="stylesheet" href="<?php echo e(asset('css/bootstrap.min.css')); ?>"/>
    <!-- Slick -->
    <link type="text/css" rel="stylesheet" href="<?php echo e(asset('css/detailcart/slick.css')); ?>"/>
    <link type="text/css" rel="stylesheet" href="<?php echo e(asset('css/detailcart/slick-theme.css')); ?>"/>
    <!-- nouislider -->
    <link type="text/css" rel="stylesheet" href="<?php echo e(asset('css/detailcart/nouislider.min.css')); ?>"/>

    <!-- Font Awesome Icon -->
    <link rel="stylesheet" href="<?php echo e(asset('css/detailcart/font-awesome.min.css')); ?>">

    <!-- Custom stlylesheet -->
    <link type="text/css" rel="stylesheet" href="<?php echo e(asset('css/detailcart/style.css')); ?>"/>
    <!-- Css Styles -->
    

    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">

    <style>
        .btnTrans{
            color:white;
        }
        .fa-shopping-cart:before{
            content:"\f07a"

        }
        [type="date"] {
            background:#fff url('https://cdn1.iconfinder.com/data/icons/cc_mono_icon_set/blacks/16x16/calendar_2.png')  97% 50% no-repeat ;
        }
        [type="date"]::-webkit-inner-spin-button {
            display: none;
        }
        [type="date"]::-webkit-calendar-picker-indicator {
            opacity: 0;
        }
        label {
            display: block;
        }
        /* input {
            border: 1px solid #c4c4c4;
            border-radius: 5px;
            background-color: #fff;
            padding: 3px 5px;
            box-shadow: inset 0 3px 6px rgba(0,0,0,0.1);
            width: 190px;
        } */
    </style>

    <div class="container">
        <div class="section-header" style="text-align:left;margin-left:15px;margin-top:10px;margin-bottom:10px;">
            <h2><?php echo e($pegawai->pegawai_jasa); ?></h2>
        </div>
        
        <form action="<?php echo e(url('/user/doupdatedetailcart')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <div id="contPeg" style="margin-left:15px;">
                <div style="float:left;">

                    <?php if($pegawai->pegawai_photo=="" || $pegawai->pegawai_photo==null): ?>
                        <img src="<?php echo e(asset('/img/profile.png')); ?>" class="card-img-top" style="height=50px;width:100px;" alt="...">
                    <?php else: ?>
                        <img src="<?php echo e(asset('/storage/photos/'.$pegawai->pegawai_photo)); ?>" class="card-img-top" style="height=50px;width:100px;" alt="...">
                    <?php endif; ?>

                </div>
                <div style="float:left;margin-left:10px;">
                    Nama <br>
                    Alamat <br>
                </div>
                <div style="float:left;margin-left:5px;">
                    : <?php echo e($pegawai->pegawai_nama); ?><br>
                    : <?php echo e($pegawai->pegawai_alamat); ?><br>
                </div>
                <input type="hidden" name="idpegawai" value="<?php echo e($pegawai->id); ?>">
                <div class="btn btn-warning btnTrans" style="float:right;">
                    <button type="submit">Update Cart</button>
                </div>
                <div style="clear:both"></div>

                <div style="margin-top:30px;margin-bottom:50px;">
                    <div class="shadow-lg" style="padding:20px;width:49.5%;float:left;margin-right:10px;border-radius:10px;pading:20px;">
                        <label for="tanggal">Alamat</label>
                        <input type="text" name="alamat" id="alamat" value="<?php echo e($cart->alamat); ?>" readonly>
                        <a href="" data-target="#pilihalamat" data-toggle="modal">
                            <button class="btn btn-warning btnTrans" data-target="#pilihalamat" data-toggle="modal" id="alamatlain">
                                Pilih alamat lain
                            </button>
                        </a>
                    </div>
                    <div class="shadow-lg" style="padding:20px;width:49.5%;float:left;border-radius:10px;">
                        <label for="tanggal">Tanggal Sewa</label>
                        <input type="date" value="<?php echo e(date('Y-m-d', strtotime($cart->tanggal_sewa))); ?>" name="tanggal" id="tanggal">

                    </div>
                </div>
                <div style="clear:both"></div>

            </div>
        </form>

        <hr>

        <div id="contAddOn">
            <div class="section-header" style="text-align:left;margin-left:15px;">
                <h2>Add On</h2>
                <div class="new-arrivals-content" style="margin-top:20px;">
                    <div class="row">
                        <?php $__currentLoopData = $addons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $addon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-md-3 col-sm-4">
                                <div class="single-new-arrival">
                                    <div class="single-new-arrival-bg">

                                        
                                        <img src="<?php echo e(asset('img/sapu.png')); ?>" alt="new-arrivals images" style="object-fit:fill;">

                                        <div class="single-new-arrival-bg-overlay"></div>

                                        
                                        <div class="new-arrival-cart" >
                                            <p>
                                                <span class="lnr lnr-cart"></span>
                                                <button data-toggle="modal" data-target="#modalEditAddOn<?php echo e($addon['id']); ?>" style="color:white;">Edit</button>

                                            </p>
                                            <p class="arrival-review pull-right">
                                                <span class="lnr lnr-heart"></span>
                                                <span class="lnr lnr-frame-expand"></span>
                                            </p>
                                        </div>
                                    </div>
                                    <h4><a href="#"><?php echo e($addon->barang->barang_nama); ?></a></h4>
                                    <p class="arrival-product-price">
                                        Rp.<?php echo e($addon->barang->barang_harga); ?> x <?php echo e($addon->jumlah); ?>


                                    </p>
                                    <a href="<?php echo e(url('user/doremoveaddonedit/'.$addon['id'].'/'.$pegawai->id)); ?>">&nbsp;&nbsp;&nbsp;<button data-toggle="modal" data-target="#modalEditAddOn<?php echo e($addon['id']); ?>" style="color:red; font-size:15px;font-weight:normal;margin-top:9px;margin-left:-10px;">Remove</button></a>

                                </div>
                            </div>
                            
                            <div class="modal fade bd-example-modal-sm" id="modalEditAddOn<?php echo e($addon['id']); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
                                <div class="modal-dialog modal-dialog-centered modal-sm" role="document">
                                    <div class="modal-content">
                                        <form method="post" action="<?php echo e(url('/user/doeditaddonedit')); ?>">
                                            <?php echo csrf_field(); ?>
                                            <div class="modal-header">
                                                <h5 class="modal-title" id="exampleModalLongTitle"><?php echo e($addon->barang->barang_nama); ?></h5>
                                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                        <span aria-hidden="true">&times;</span>
                                                    </button>
                                                </div>

                                            <div class="modal-body" style="color:black;">
                                                Jumlah :

                                                <?php
                                                    $brg = "";
                                                    foreach ($databarang as $barang) {
                                                        if($barang->id == $addon->id_barang){
                                                            $brg = $barang;
                                                        }
                                                    }
                                                ?>
                                                <select name="jumlah" id="" class="form-select" aria-label="Default select example">
                                                    <?php for($i = 1; $i <= $brg->barang_stok; $i++): ?>
                                                        <?php if($i == $addon->jumlah): ?>
                                                            <option value="<?php echo e($i); ?>" selected><?php echo e($i); ?></option>
                                                        <?php else: ?>
                                                            <option value="<?php echo e($i); ?>"><?php echo e($i); ?></option>
                                                        <?php endif; ?>

                                                    <?php endfor; ?>
                                                </select>
                                                <input type="hidden" name="idaddon" value="<?php echo e($addon->id); ?>">
                                                <input type="hidden" name="idpegawai" value="<?php echo e($pegawai->id); ?>">
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                                <button type="submit" name="btnAdd" class="btn btn-primary">Save</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                            

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>

            </div>
        </div>

        <hr>

        <div id="contBarang">
            <div class="container" style="margin-left:0px;margin-right:0px;">
                <div class="section-header" style="text-align:left;">
                    <h2>Barang</h2>
                </div><!--/.section-header-->
                <div class="new-arrivals-content" style="margin-top:20px;">
                    <div class="row">
                        <?php $__currentLoopData = $databarang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $barang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-md-3 col-sm-4">
                                <div class="single-new-arrival">
                                    <div class="single-new-arrival-bg">

                                        <?php
                                            $addon = null;
                                            foreach ($addons as $key => $addon1) {
                                                if($addon1['id'] == $barang->id){
                                                    $addon = $addon1;
                                                }
                                            }
                                        ?>

                                        
                                        <img src="<?php echo e(asset('img/sapu.png')); ?>" alt="new-arrivals images" style="object-fit:fill;">

                                        <div class="single-new-arrival-bg-overlay"></div>
                                        <?php if($addon != null): ?>
                                            <div class="sale bg-1">
                                                <p>In Cart</p>
                                            </div>
                                        <?php elseif($barang->barang_stok > 0): ?>
                                            <div class="sale bg-2">
                                                <p>In Stock</p>
                                            </div>
                                        <?php else: ?>
                                            <div class="sale bg-1" style="width:92px;background-color:gray;">
                                                <p>Out of Stock</p>
                                            </div>
                                        <?php endif; ?>

                                        
                                        <?php if($addon == null): ?>
                                            <div class="new-arrival-cart" >
                                                <p>
                                                    <span class="lnr lnr-cart"></span>
                                                    <button id="B<?php echo e($barang->id); ?>" data-toggle="modal" data-target="#modalAddOn<?php echo e($barang->id); ?>" style="color:white;">Add <span> to </span> Cart</button>
                                                </p>
                                                <p class="arrival-review pull-right">
                                                    <span class="lnr lnr-heart"></span>
                                                    <span class="lnr lnr-frame-expand"></span>
                                                </p>
                                            </div>
                                        <?php endif; ?>


                                    </div>
                                    <h4><a href="#"><?php echo e($barang->barang_nama); ?></a></h4>
                                    <p class="arrival-product-price">Rp.<?php echo e($barang->barang_harga); ?></p>
                                </div>
                            </div>

                            
                            <div class="modal fade bd-example-modal-sm" id="modalAddOn<?php echo e($barang->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
                                <div class="modal-dialog modal-dialog-centered modal-sm" role="document">
                                    <div class="modal-content">
                                        <form method="post" action="/user/dotambahaddonedit/<?php echo e($barang->id); ?>">
                                            <?php echo csrf_field(); ?>
                                            <div class="modal-header">
                                                <h5 class="modal-title" id="exampleModalLongTitle">Add <?php echo e($barang->barang_nama); ?></h5>
                                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                        <span aria-hidden="true">&times;</span>
                                                    </button>
                                                </div>
                                            <div class="modal-body" style="color:black;">
                                                Jumlah :
                                                <select name="jumlah" id="" class="form-select" aria-label="Default select example">
                                                    <?php if($barang->barang_stok > 0): ?>
                                                        <?php if($addon != null): ?>
                                                            <?php for($i = 1; $i <= $barang->barang_stok - $addon['jumlah']; $i++): ?>
                                                                <option value="<?php echo e($i); ?>"><?php echo e($i); ?></option>
                                                            <?php endfor; ?>
                                                        <?php else: ?>
                                                            <?php for($i = 1; $i <= $barang->barang_stok; $i++): ?>
                                                                <option value="<?php echo e($i); ?>"><?php echo e($i); ?></option>
                                                            <?php endfor; ?>
                                                        <?php endif; ?>
                                                    <?php else: ?>
                                                        <option value="null">Out of Stock</option>
                                                    <?php endif; ?>

                                                </select>
                                                <input type="hidden" name="idbarang" value="<?php echo e($barang->id); ?>">
                                                <input type="hidden" name="idpegawai" value="<?php echo e($pegawai->id); ?>">
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                                <?php if($barang->barang_stok > 0): ?>
                                                    <button type="submit" name="btnAdd" class="btn btn-primary">Add</button>
                                                <?php else: ?>
                                                    <button type="submit" name="btnAdd" class="btn btn-secondary" disabled>Out of Stock</button>
                                                <?php endif; ?>

                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                            


                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </div>
                </div>
            </div><!--/.container-->
        </div>

    </div>

    <script type="text/javascript" src="/js/functions.js"></script>
    
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

    <!-- Include all js compiled plugins (below), or include individual files as needed -->
    <script src="<?php echo e(asset('js/detailcart/jquery.js')); ?>"></script>

    <!--modernizr.min.js-->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/modernizr/2.8.3/modernizr.min.js"></script>

    <!--bootstrap.min.js-->
    <script src="<?php echo e(asset('/js/detailcart/bootstrap.min.js')); ?>"></script>

    <!-- bootsnav js -->
    <script src="<?php echo e(asset('/js/detailcart/bootsnav.js')); ?>"></script>

    <!--owl.carousel.js-->
    <script src="<?php echo e(asset('js/detailcart/owl.carousel.min.js')); ?>"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.4.1/jquery.easing.min.js"></script>

    <!--Custom JS-->
    <script src="<?php echo e(asset('js/detailcart/custom.js')); ?>"></script>

    <!-- Date picker -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>

    <script type="text/javascript">
        $(document).ready(function() {
            $('#alamatlain').click(function(){
                $('#alamat').prop('readonly',false);
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.base-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Gigi\Documents\Gigi\Semester 5\ProjekSDP\projek\resources\views/user/user_detail_cart_update.blade.php ENDPATH**/ ?>