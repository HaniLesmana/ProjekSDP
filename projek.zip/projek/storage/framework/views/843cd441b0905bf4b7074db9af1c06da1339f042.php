<div class="chat-history">
    <ul class="m-b-0">
        <?php $__currentLoopData = $datachat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i=> $chat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($chat->chat_from == "pegawai"): ?>
        <li class="clearfix">
            <div class="message-data text-right">
                
                <span class="message-data-time"><?php echo e($chat->created_at); ?></span>
                

                <?php if($chat->user_destination->pegawai_photo == "" || $chat->user_destination->pegawai_photo==null): ?>
                    <img src="<?php echo e(asset('/img/profile.png')); ?>" class="card-img-top rounded" style="height:40px;" alt="...">
                <?php else: ?>
                    <img src="<?php echo e(asset('/storage/photos/'.$chat->user_destination->pegawai_photo)); ?>" class="card-img-top rounded" style="height:40px;" alt="...">
                <?php endif; ?>
            </div>
            
            <div class="message other-message float-right"><?php echo e($chat->chat_text); ?></div>
        </li>
        <?php else: ?>
        <li class="clearfix">
            <div class="message-data text-left">
                
                <span class="message-data-time"><?php echo e($chat->created_at); ?></span>
                

                <?php if($chat->user_sender->user_photo == "" || $chat->user_sender->user_photo==null): ?>
                    <img src="<?php echo e(asset('/img/profile.png')); ?>" class="card-img-top rounded" style="height:40px;" alt="...">
                <?php else: ?>
                    <img src="<?php echo e(asset('/storage/photos/'.$chat->user_sender->user_photo)); ?>" class="card-img-top rounded" style="height:40px;" alt="...">
                <?php endif; ?>
            </div>
            
            <div class="message other-message float-left"><?php echo e($chat->chat_text); ?></div>
        </li>
        <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
    </ul>
</div>
<?php /**PATH D:\GitHub_Repost\ProjekSDP\projek\resources\views/pegawai/chat_ajax.blade.php ENDPATH**/ ?>