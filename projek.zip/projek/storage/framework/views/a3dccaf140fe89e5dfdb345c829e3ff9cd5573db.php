<style>
body{
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif
}

</style>

<nav class="navbar navbar-expand-lg navbar-light" style="background-color: rgba(255,255,255,0.9);  background-image: linear-gradient( rgba(0,0,0,0.1),rgba(220,220,220,0),rgba(225,225,225,0));">
        <div class="container">
            <a class="navbar-brand" id="logo" href="#"></a>
            <button class="navbar-toggler" type="button"
            data-toggle="collapse" data-target="#navbarNavAltMarkup"
            aria-controls="navbarNavAltMarkup" aria-expanded="false"
            aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
                <div class="navbar-nav ml-auto" style="padding-top:20px;float:right;">

                    <form action="<?php echo e(url('/home/user')); ?>" method="get">
                        <a class="nav-item nav-link" style="padding-left:0px;padding-right:0px;">
                            <input class="btn" type="submit" value="HOME">
                            
                        </a>
                    </form>
                    <form action="<?php echo e(url('/user/profile')); ?>" method="get">
                        <a class="nav-item nav-link" style="padding-left:0px;padding-right:0px;">
                            <input class="btn" type="submit" value="PROFILE">
                        </a>
                        
                    </form>
                    <form action="<?php echo e(url('/home/transaksi_sewa')); ?>" method="get">
                        <a class="nav-item nav-link" style="padding-left:0px;padding-right:0px;">
                            <input class="btn" type="submit" value="CART">
                        </a>
                        
                    </form>
                    <form action="<?php echo e(url('/home/history')); ?>" method="get">
                        <a class="nav-item nav-link" style="padding-left:0px;padding-right:0px;">
                            <input class="btn" type="submit" value="HISTORY">
                        </a>
                        
                    </form>
                    <form action="<?php echo e(url('/home/ongoingtrans')); ?>" method="get">
                        <a class="nav-item nav-link" style="padding-left:0px;padding-right:0px;">
                            <input class="btn" type="submit" value="ONGOING">
                        </a>
                        
                    </form>
                    <form action="<?php echo e(url('/user/voucher')); ?>" method="get">
                        <a class="nav-item nav-link" style="padding-left:0px;padding-right:0px;">
                            <input class="btn" type="submit" value="VOUCHER">
                        </a>
                        
                    </form>
                    <form action="<?php echo e(url('/logout')); ?>" method="get" style="padding-top:7px;">
                        <button type ="submit" class="btn btn-warning tombolSignOut" style="color:white;">Sign Out</button>
                    </form>
                </div>
            </div>
        </div>
</nav>
<?php /**PATH D:\GitHub_Repost\ProjekSDP\projek\resources\views/user/navbarUser.blade.php ENDPATH**/ ?>