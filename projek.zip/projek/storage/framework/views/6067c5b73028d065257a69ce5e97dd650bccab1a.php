<div class="vertical-nav" id="sidebar" style="background-color:#396EB0;min-height:100vh">

    <ul class="nav flex-column mb-0">
        <a class="navbar-brand" id="gambar" href="#"></a>
      <li class="nav-item">
        <a href="/home/admin" class="nav-link font-italic dropdown-item"><i class="fas fa-home"> Home</i></a>
      </li>
      <li class="nav-item">
        <a href="/listRequest" class="nav-link font-italic dropdown-item">
            <i class="fas fa-dollar-sign"> Top Up</i>
        </a>
      </li>
      <li class="nav-item">
        <a href="/listWithdraw" class="nav-link font-italic dropdown-item">
                  Withdraw
              </a>
      </li>
      <li class="nav-item">
        <a href="/admin/listpegawai" class="nav-link font-italic dropdown-item">
                <i class="fas fa-users"> Pegawai</i>
              </a>
      </li>
      <li class="nav-item">
        <a href="/admin/listKategori" class="nav-link font-italic dropdown-item">
                <i class="fas fa-clipboard-list"> Kategori </i>
              </a>
      </li>
      <li class="nav-item">
        <a href="/admin/listbarang" class="nav-link font-italic dropdown-item">
                <i class="fas fa-box-open"> Barang</i>
              </a>
      </li>
      <li class="nav-item">
        <a href="/admin/listVoucher" class="nav-link font-italic dropdown-item">
                  Voucher
              </a>
      </li>
      <!-- <li class="nav-item">
        <a href="/admin/listVoucher" class="nav-link font-italic dropdown-item">
                  Pembayaran Pegawai
              </a>
      </li> -->
    </ul>
    <button type ="submit" class="btn btn-warning tombol" style="position:absolute;bottom:30px;margin-left:25px"><a href="/" style="text-decoration:none;color:white;">Sign Out</a></button>
  </div>
<?php /**PATH C:\Users\Gigi\Documents\Gigi\Semester 5\ProjekSDP\projek\resources\views/admin/navbarAdmin.blade.php ENDPATH**/ ?>