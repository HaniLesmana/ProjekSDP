
<!-- Navbar -->
<?php $__env->startSection('header'); ?>
    <?php echo $__env->make('user.navbarUser', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<!-- Akhir Navbar -->
<?php $__env->startSection('main'); ?>


    <div class="container">
        <div class="section-header" style="text-align:left;">
            <h2>Detail on going</h2>
        </div>
        <div class="">
            <div class="card">
                <h5 class="card-title"><?php echo e($dtransewa->pegawai->pegawai_nama); ?></h5>
                <p class="card-text">Alamat:<?php echo e($dtransewa->pegawai->pegawai_alamat); ?></p>
                <p class="card-text">Telepon:<?php echo e($dtransewa->pegawai->pegawai_telepon); ?></p>
                <p class="card-text">Jasa:<?php echo e($dtransewa->pegawai->pegawai_jasa); ?></p>
                
            </div>
        </div>
        <div class="card">
            <table class="table table-striped">
                <thead style="background-color:#E8D0B3;">
                
                  <tr>
                    <th>No</th>
                    <th>Nama Barang</th>
                    <th>Kategori</th>
                    <th>Harga</th>
                    <th>Jumlah</th>
                  </tr>
                </thead>
                <tbody>
                    <?php if(isset($dtransbarang)): ?>
                        <?php $__currentLoopData = $dtransbarang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i=> $dbarang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        
                            <tr>
                                <td><?php echo e($i+1); ?></td>
                                <td><?php echo e($dbarang->barang->barang_nama); ?></td>
                                <td><?php echo e($dbarang->barang->kategori->kategori_nama); ?></td>
                                <td><?php echo e($dbarang->barang->barang_harga); ?></td>
                                <td><?php echo e($dbarang->barang_jumlah); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>

        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.base-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\GitHub_Repost\ProjekSDP\projek\resources\views/user/detailongoing.blade.php ENDPATH**/ ?>