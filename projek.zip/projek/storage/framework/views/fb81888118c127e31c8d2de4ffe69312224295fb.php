
<!-- Navbar -->
<?php $__env->startSection('header'); ?>
    <?php echo $__env->make('user.navbarUser', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<!-- Akhir Navbar -->
<?php $__env->startSection('main'); ?>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <style>
        .hideScrollbar::-webkit-scrollbar {
            display: none;
        }

            /* Hide scrollbar for IE, Edge and Firefox */
        .hideScrollbar {
            -ms-overflow-style: none;  /* IE and Edge */
            scrollbar-width: none;  /* Firefox */
        }
    </style>

    <div class="container">
        <div class="shadow-lg" style="height: 100px;width:100%;padding:10px;">
            <div style="float:left;">
                <div style="">
                    <?php if($pegawai->pegawai_photo=="" || $pegawai->pegawai_photo==null): ?>
                        <img src="<?php echo e(asset('img/profile.png')); ?>" class="card-img-top rounded" style="height:80px;width:80px;border-radius: 50%;object-fit: cover;" alt="...">
                    <?php else: ?>
                        <img src="<?php echo e(asset('/storage/photos/'.$pegawai->pegawai_photo)); ?>" class="card-img-top rounded" style="height:80px;width:80px;border-radius: 50%;" alt="...">
                    <?php endif; ?>

                </div>
            </div>
            <div style="float:left;padding:8px 0px 0px 30px;font-size:18px;width:140px;">
                <b><?php echo e($pegawai->pegawai_jasa); ?></b><br>
                <label class="lab" style="line-height:20px;margin-top:10px;"><?php echo e($pegawai->pegawai_nama); ?></label><br>

            </div>
        </div>
        <br>

        <!-- CHAT AJAX -->
        <div class="shadow rounded hideScrollbar" id="chattext" style="height:452px;margin-right:-20px;padding:20px;overflow: auto;">


        </div>

        
            <div class="input-group mb-3" style="margin-right:-20px;position:fixed;bottom:0px;width:1160px;background-color:white">
                <input type="text" class="form-control" id="inputchattext" placeholder="Tulis pesan...">
                <input type="hidden" id="idpegawai" name="idpegawai" value="<?php echo e($pegawai->id); ?>">
                <button class="btn btn-outline-success" type="submit" id="btnsend">Send</button>
            </div>
        
        
    </div>

    <script>


        $(document).ready(function() {
            // alert("berhasil");
            loadChatAjax2();

            $("#btnsend").click(function(){
                //alert($("#inputchattext").val());
                // data.order = order.positions;
                loadChatAjax();
            });
        });

        function loadChatAjax() {
            var inputchattext=$("#inputchattext").val()+"";
            var idpegawai = $('#idpegawai').val();
            $.ajax({
                type: 'post',
                url: '/user/chat_ajax/',
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                data:{
                    datachat:inputchattext,
                    // _token:$('input[name=_token]').val(),
                    idpegawai:idpegawai,
                    _token: '<?php echo e(csrf_token()); ?>'
                },
                success: function(data) {
                    //alert("berhasil");
                    // loadChatAjax2();
                }
            });
        }
        setInterval(()=>{
            loadChatAjax2();
        },500);

        function loadChatAjax2() {
            // var inputchattext=$("#inputchattext").val()+"";
            var idpegawai = $('#idpegawai').val();
            $.ajax({
                type: 'post',
                url: '/user/chat_ajax2',
                // headers: {
                //     'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                // },
                data:{
                    idpegawai:idpegawai,
                    _token: '<?php echo e(csrf_token()); ?>'
                },
                success: function(data) {
                    $("#chattext").empty();
                    $("#chattext").append(data);
                    var objDiv = document.getElementById("chattext");
                    objDiv.scrollTop = objDiv.scrollHeight;
                }
            });
        }



    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.base-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Gigi\Documents\Gigi\Semester 5\ProjekSDP\projek\resources\views/user/chat.blade.php ENDPATH**/ ?>