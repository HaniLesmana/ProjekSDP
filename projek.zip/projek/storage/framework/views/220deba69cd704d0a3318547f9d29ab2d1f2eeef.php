<?php $__env->startSection('header'); ?>
    <?php echo $__env->make('admin.navbarAdmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('main'); ?>
<style>
    .main{
        background-color:#DBD0C0;
        margin-top: -30px;
        padding: 55px;
    }
</style>
<div class="container mt-5 mb-5 d-flex justify-content-center" style="padding-top:10px; padding-bottom:20px;background-color:#DBD0C0">
    <div class="card px-1 py-4">
        <div class="card-body" style="width:400px;padding:10px 25px 10px 25px;">
        
            <h4 class="card-title mb-3" style="text-align: center;">Detail</h4>
            <div class="row">
                
                Tanggal&nbsp;&nbsp;&nbsp;&nbsp;: <?php echo e($dataheader->htranstpwd_tanggal); ?> <br>
                Tipe&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;: <?php echo e($dataheader->htranstpwd_tipe); ?> <br>
                Email&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;: <?php echo e($email); ?> <br> <br>
                <table class="table table-striped">
                    <thead style="background-color:#E8D0B3;">
                      <tr>
                        <th>Nominal</th>
                        <th>Jumlah</th>
                        
                        <th></th>
                      </tr>
                    </thead>
                    <?php
                        if(isset($datadetail)){
                            foreach ($datadetail as $data) {
                                echo '<tbody>';
                                    echo'<td>'.data_get($data,'dtranstpwd_nominal').'</td>';
                                    echo'<td>'.data_get($data,'dtranstpwd_jumlah').'</td>';
                                echo '</tbody>';
                            }
                        }
                    ?>
                    
                  </table>
            </div>
            <div style="margin-top: 20px">
                <form action="<?php echo e(url('admin/detailTopUp/actionAccept/'.$id)); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <button style="color:white;height:35px;width:100%;border-radius:3px;border:1px solid black; background-color:#FACE7F;text-align:center;">
                    
                    Accept
                    </button>
                </form>
                <form action="<?php echo e(url('admin/detailTopUp/actionDecline/'.$id)); ?>" method="post" style="margin-top: 10px">
                    <?php echo csrf_field(); ?>
                    <button style="color:white;height: 35px;width:100%;border-radius:3px;border:1px solid black; background-color:Red;text-align:center;">
                    
                    Decline
                    </button>
                </form>
            </div>

            
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.base-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Gigi\Documents\Gigi\Semester 5\ProjekSDP\projek\resources\views/admin/detailTopUp.blade.php ENDPATH**/ ?>