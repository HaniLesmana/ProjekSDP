<?php $__env->startSection('main'); ?>
<div class="container">
    <h1>Hello, Admin</h1>
    <hr style="border: 1px solid gray;">
    <h2>Saldo : <?php echo e($admin); ?></h2>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.base-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\GitHub_Repost\ProjekSDP\projek\resources\views/admin/home_admin.blade.php ENDPATH**/ ?>